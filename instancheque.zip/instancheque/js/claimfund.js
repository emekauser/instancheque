//////////////////////for TRON
 var TronWeb;
  var HttpProvider ;
  var fullNode = 'https://api.trongrid.io';//'
var solidityNode ='https://api.trongrid.io';//
var eventServer = 'https://api.trongrid.io/';//
require(['TronWeb'],function(Tronw){
  TronWeb=Tronw;
  HttpProvider = TronWeb.providers.HttpProvider;
  // fullNode = new HttpProvider('https://api.shasta.trongrid.io');//'https://api.trongrid.io:8090';//'
   //solidityNode =new HttpProvider('https://api.shasta.trongrid.io');//'https://api.trongrid.io:8091';//
   //eventServer = 'https://api.shasta.trongrid.io/';//'https://api.trongrid.io/';//
});

var privatekey="";//private key of the sender
var publickey="";//public key of the sender
var trxdollar="";//Dolar exchnage rate o TRX coin
var email="";//sender email address
var tronWeb;
var userbalance;
var instanCaddress="";
var amount;
var valcode;
var userdata={};
var transactionid;
var url="process";
var priceindollar=0;
const auth="";
// Create instance of contract object
const contract = {
    "instanTransfer.sol:instanTransfer": {
        "address": "TCXwgXXHEvj6diedYKm8oVJdp51NzN7ZWN",
        "abi":[
    {
      "constant": true,
      "inputs": [
        {
          "name": "",
          "type": "uint256"
        }
      ],
      "name": "transactions",
      "outputs": [
        {
          "name": "time",
          "type": "uint256"
        },
        {
          "name": "amount",
          "type": "uint256"
        },
        {
          "name": "sender",
          "type": "address"
        },
        {
          "name": "status",
          "type": "bool"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "constructor"
    },
    {
      "constant": true,
      "inputs": [],
      "name": "getBalance",
      "outputs": [
        {
          "name": "balance",
          "type": "uint256"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "sender",
          "type": "address"
        },
        {
          "name": "amount",
          "type": "uint256"
        },
        {
          "name": "receiver",
          "type": "address"
        },
        {
          "name": "time",
          "type": "uint256"
        }
      ],
      "name": "claimFund",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "time",
          "type": "uint256"
        }
      ],
      "name": "transferfund",
      "outputs": [],
      "payable": true,
      "stateMutability": "payable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "sender",
          "type": "address"
        },
        {
          "name": "amount",
          "type": "uint256"
        },
        {
          "name": "time",
          "type": "uint256"
        }
      ],
      "name": "storeUnclaimedTransaction",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "sender",
          "type": "address"
        },
        {
          "name": "amount",
          "type": "uint256"
        },
        {
          "name": "time",
          "type": "uint256"
        }
      ],
      "name": "storeTransaction",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "amount",
          "type": "uint256"
        }
      ],
      "name": "withdraw",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "owner",
          "type": "address"
        }
      ],
      "name": "changeOwner",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": true,
      "inputs": [],
      "name": "getContractBalance",
      "outputs": [
        {
          "name": "balance",
          "type": "uint256"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    }
  ]
    }
};
var processtransaction;
var typeoffund;
var nairadollar=360;
///////////////////////////////////////
var validated=false;
var spinarray=[];

function callGeneral(url,message,type){
      $.ajax({ url:url,
            method: type,
            data:  message,
            crossDomain:true,
            cache: false,
            error:function(jqXHR,exception){
            //alert(jqXHR);
            },
            success: function(response){
               processCall(response);
            }
            
        });
       
}
function callCoinMarket(url){
      $.ajax({ url:url,
            method: "get",
            crossDomain:true,
            cache: false,
            error:function(jqXHR,exception){
           // alert(jqXHR);
            },
            success: function(response){
              var r= response.data.quotes;
             priceindollar=r.USD.price;
             callGeneral("process",{transactionid:transactionid,messagetype:"getAmount"},"post"); //get amount of TRX to Received
            }
            
        });    
}
var index=0;
function processCall(message){
    var id=message.messagetype;
  if(message.messagetype==="getDatas"){
     
      callGeneral(url,{transactionid:transactionid,messagetype:"getUnClaimedData"},"post"); 
  }else if(message.messagetype==="verifyValCode"){
      if(message.status){
          $('#verification').css("display","none");
          $('#claimfundtrx').css("display","none");
          $('#claimfundnaira').css("display","none");
          $('#typeofund').css("display","flex");
          //connect and call smaertcontract
          
          callGeneral(url,{auth:"87124644784894",messagetype:"getDatas"},"post"); 
      }else{
          alert("Wrong code,pls resend SMS code");
          $('#entercode').css("display","none");
      $('#clickverify').css("display","flex");
      }
  }else if(message.messagetype==="getUnClaimedData"){
     createSpinner("transloader","getUnClaimedData"); 
     userdata=message.message;
     accessTRON();
  }else if(message.messagetype==="getAmount"){
      if(message.status){
         amount=message.amount;
         amount=parseFloat(amount).toFixed(2);
         var d=amount*priceindollar;
         d=d.toFixed(2);
         $('#amounttoclaim').text("Get Your Money. Balance = "+ numberWithCommas(amount)+" TRX ($"+ numberWithCommas(d)+")");
         
      }else{
          alert("The fund had been claimed by the real beneficiary (fund receiver) or you are entering the wrong transaction ID");
            $('#sucessfultran').css("display","none");
                   $('#verification').css("display","none");
      $('#claimfundtrx').css("display","none");
     $('#claimfundnaira').css("display","none");
      $('#typeofund').css("display","none");
      }
  }else if(message.messagetype==="storeToClaimedData"){
      
               alert("Successful Transaction, Your Fund will be transfered to the acccount provided");
                  $('#confirmationdailog').modal('hide');
                  $("#fullname").val("");
                 $("#bankname").val("");
                  $("#accountnumber").val("");
                   $('#sucessfultran').css("display","flex");
                   $('#verification').css("display","none");
      $('#claimfundtrx').css("display","none");
     $('#claimfundnaira').css("display","none");
      $('#typeofund').css("display","none");

  }

   /////////////this part finalizes the last part of the processing
   for(var j=0;j<spinarray.length;j++){
           // $('#contact').append(spinarray.splice(0, spinarray.indexOf(id)+1));
           if(spinarray[j].id==id){//this compares id sent from server and client id in
               //other to remove data from the queue and spinarray
            if(spinarray[j].type=="Spinner"){
               spinarray[j].name.hide();
             $('#'+spinarray[j].loader).remove();
          
            } else{
               $('#'+spinarray[j].loader).append("?") 
               $('#'+spinarray[j].loader).css("color","#33ff00")
               if(spinarray[j].is!="no"){
                 $('#'+spinarray[j].name).remove();   
               }
            }  
           
           spinarray.splice(j,1);
           
           }
          
       } 
      
}
$(document).ready(function(){
    $.support.cors=true; 
    transactionid=$('#transid').text();
    createSpinner("transloader","getAmount"); 
    callCoinMarket("https://api.coinmarketcap.com/v2/ticker/1958/"); //get price in doller
   
     $('#verification').css("display","flex");
      $('#claimfundtrx').css("display","none");
     $('#claimfundnaira').css("display","none");
      $('#typeofund').css("display","none");
       $('#sucessfultran').css("display","none");
      callGeneral(url,{transactionid:transactionid,messagetype:"getAmount"},"post");
   $("#trx").click(function(){//event is triggered whne user want to claim fund in trx
       $('#verification').css("display","none");
      $('#claimfundtrx').css("display","flex");
     $('#claimfundnaira').css("display","none");
      $('#typeofund').css("display","none");
       $('#sucessfultran').css("display","none");
   });
   $("#naira").click(function(){//event is called when user want to claim fund in Naira
       var d=amount*priceindollar*nairadollar;
       $('#amountinaira').html("Amount to Receive &#8358; "+numberWithCommas(d.toFixed(2)));
       $('#verification').css("display","none");
      $('#claimfundtrx').css("display","none");
     $('#claimfundnaira').css("display","flex");
      $('#typeofund').css("display","none");
       $('#sucessfultran').css("display","none");
   });
    $("#sendsms").click(function(){//This is triggered in order to verify user claim
        //call php code here
        createSpinner("transloader","getValcode"); 
       callGeneral(url,{transactionid:transactionid,messagetype:"getValcode"},"post");  //send sms to receiver phonenumber  
     $('#entercode').css("display","flex");
      $('#clickverify').css("display","none");
   });
    $("#submitcode").click(function(){//This is triggered for authentication of user
        //call php code here
        createSpinner("transloader","verifyValCode"); 
       callGeneral(url,{transactionid:transactionid,valcode:$('#valcode').val(),messagetype:"verifyValCode"},"post");    
     $('#entercode').css("display","flex");
      $('#clickverify').css("display","none");
   });
     $("#claim2").click(function(){//Triggered to claim the fund in naira
         typeoffund="naira";
         var allow=false;
          var fullname=$("#fullname").val();
          var bankname=$("#bankname").val();
          var accountnumber=$("#accountnumber").val();
          var error="Fullname is required";
          if(fullname!==""){
              error="Account number is required"
             if(accountnumber!==""){
                 error="Bank name is Required";
                if(bankname!==""){
                       allow=true;
                }
             
             }
          }
          if(allow){
            var d=amount*priceindollar*nairadollar;
            d=parseFloat(d).toFixed(2);
              $("#message").html("Sending.."+numberWithCommas(amount)+" TRX (&#8358; "+numberWithCommas(d)+")"
                                 +"<br>To "
                                 +"<br>Full Name       "+fullname
                                 +"<br>Bank Name       "+bankname
                                 +"<br>Account Number  "+accountnumber
                                );
              $('#confirmationdailog').modal('show');
          }else{
              alert(error);
          }
     });  
      $("#claim").click(function(){//riggered to claim the fund i TRX 
           typeoffund="trx";
         var allow=false;
          var trxaddress=$("#trxaddress").val();
                    error="Your Wallet Address is Required";
                    if(trxaddress!==""){
                       allow=true;
                    }
                 
          if(allow){
            var d=amount*priceindollar;
            d=parseFloat(d).toFixed(2);
              $("#message").html("Sending.."+numberWithCommas(amount)+" TRX ($"+numberWithCommas(d)+")"
                                 +"<br>To "
                                 +"<br>Ton Address       "+trxaddress
                                );
              $('#confirmationdailog').modal('show');
          }else{
              alert(error);
          }
     });  
      $("#proceed").click(function(){//this is Triggered to enforce the claim and get the fund
          var fullname=$("#fullname").val();
          var bankname=$("#bankname").val();
          var accountnumber=$("#accountnumber").val();
          if(typeoffund==="naira"){
          
           createSpinner("confirmationloader","storeToClaimedData"); 
           //store unclimefund to the db
           var d=new Date();
              var time=d.getTime().toString();
              //submit banks details in other to get the fund
              var a=amount*priceindollar*nairadollar;
           callGeneral(url,{transactionid:transactionid,messagetype:"storeToClaimedData",toclaimedfund:{ttansactionid:transactionid,name:fullname,bankname:accountnumber,amount:amount,amountnaira:a,accountnumber:accountnumber,time:time}},"post"); 
        }else{
             var trxaddress=$("#trxaddress").val();
               createSpinner("confirmationloader","storeToClaimedData"); 
             //Call teh smart contract to get your fund
              processtransaction.claimFund(userdata.sender,tronWeb.toSun(amount),trxaddress,transactionid).send({
                shouldPollResponse: true,
                callValue: 0
               }).then(function(suc){
                 removeloader();
                 alert("Transaction Successful");
                 $('#confirmationdailog').modal('hide');
               }).catch(function (err) {
                   alert("Transaction Failed");
               });
              
        }
      });
       $("#cancel").click(function(){
          $('#confirmationdailog').modal('hide');
      });
});
function  numberWithCommas(number){
  var parts=number.toString().split(".");
  parts[0]=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,",");
  return parts.join(".");
}

async function accessTRON(){
     tronWeb = new TronWeb(
        fullNode,
        solidityNode,
        eventServer,
        privatekey
    );
     var count=0;
    const nodes =await tronWeb.isConnected();
    const connected = !Object.entries(nodes).map(([name, connected]) => {
        if(count===2){
        if (connected){
             processtransaction = tronWeb.contract(contract["instanTransfer.sol:instanTransfer"].abi, contract["instanTransfer.sol:instanTransfer"].address);//initialize smart contract
               $('#valcode').val("");
               removeloader();
             }else{
           alert("Error accessig  your wallet, check if your private key is correct");
        }
         }
         count++;  
            
        return connected;

    }).includes(false);
    return connected;
}

function createSpinner(button,messagespec){
    ////this method create a loading spinner and append it to a button
     var loaderid=Math.floor(Math.random()*100000).toString()+"loader";
    var loader="<div"+" class="+"loader form-control"+" id="+loaderid+"> "+"<div"+" class="+"loader-inner"+" id="+loaderid+"inner"+"> </div></div>";
    $('#'+button).prepend(loader);
    var cl0 = new CanvasLoader(loaderid+"inner", {
        id: "canvasLoader", 
        safeVML: true
    });
    cl0.setShape("spiral");
    cl0.setDiameter(20);
    cl0.setDensity(40);
    cl0.setSpeed(2);
    cl0.setFPS(24);
    cl0.setDensity(400);
    cl0.setSpeed(4);
    cl0.setFPS(120); 
    cl0.show();
  
    spinarray.push({"id":messagespec,"name": cl0,"index":spinarray.length,"loader":loaderid,"type":"Spinner"});
} 
function removeloader(){
       /////////////this part finalizes the last part of the processing
   for(var j=0;j<spinarray.length;j++){
           // $('#contact').append(spinarray.splice(0, spinarray.indexOf(id)+1));
           if(spinarray[j].id=="access"){//this compares id sent from server and client id in
               //other to remove data from the queue and spinarray
            if(spinarray[j].type=="Spinner"){
               spinarray[j].name.hide();
               $('#'+spinarray[j].loader).remove();
          
            } else{
               $('#'+spinarray[j].loader).append("?") 
               $('#'+spinarray[j].loader).css("color","#33ff00")
               if(spinarray[j].is!="no"){
                 $('#'+spinarray[j].name).remove();   
               }
            }  
           
           spinarray.splice(j,1);
           
           }
          
       } 
}

