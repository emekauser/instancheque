//////////////////////for TRO;
  var TronWeb;
  var HttpProvider ;
  var fullNode = 'https://api.trongrid.io';//'
var solidityNode ='https://api.trongrid.io';//
var eventServer = 'https://api.trongrid.io/';//
require(['TronWeb'],function(Tronw){
  TronWeb=Tronw;
  HttpProvider = TronWeb.providers.HttpProvider;
   //fullNode = new HttpProvider('https://api.shasta.trongrid.io');//'https://api.trongrid.io:8090';//'
   //solidityNode =new HttpProvider('https://api.shasta.trongrid.io');//'https://api.trongrid.io:8091';//
  // eventServer = 'https://api.shasta.trongrid.io/';//'https://api.trongrid.io/';//
});


var privatekey="";//private key of the sender
var publickey="";//public key of the sender
var trxdollar="";//Dolar exchnage rate o TRX coin
var email="";//sender email address
var tronWeb;
var userbalance;
var instanCaddress="";
var url="process";
var priceindollar=0;
var ATUOC=true;

//////////////////////////////////////
var numbercodes=[];
numbercodes[0]="0701";
numbercodes[1]="0702";
numbercodes[2]="0703";
numbercodes[3]="0704";
numbercodes[4]="0705";
numbercodes[5]="0706";
numbercodes[6]="0707";
numbercodes[7]="0708";
numbercodes[8]="0709";
numbercodes[9]="0801";
numbercodes[10]="0802";
numbercodes[11]="0803";
numbercodes[12]="0805";
numbercodes[13]="0806";
numbercodes[14]="0807";
numbercodes[15]="0808";
numbercodes[16]="0809";
numbercodes[17]="0810";
numbercodes[18]="0811";
numbercodes[19]="0812";
numbercodes[20]="0813";
numbercodes[21]="0814";
numbercodes[22]="0815";
numbercodes[23]="0816";
numbercodes[24]="0817";
numbercodes[25]="0818";
numbercodes[26]="0819";
numbercodes[27]="0902";
numbercodes[28]="0903";
numbercodes[29]="0905";
numbercodes[30]="0906";
numbercodes[31]="0907";
numbercodes[32]="0908";
numbercodes[33]="0909";
numbercodes[34]="0804";
// Create instance of contract object
const contract = {
    "instanTransfer.sol:instanTransfer": {
        "address": "TCXwgXXHEvj6diedYKm8oVJdp51NzN7ZWN",
        "abi":[
    {
      "constant": true,
      "inputs": [
        {
          "name": "",
          "type": "uint256"
        }
      ],
      "name": "transactions",
      "outputs": [
        {
          "name": "time",
          "type": "uint256"
        },
        {
          "name": "amount",
          "type": "uint256"
        },
        {
          "name": "sender",
          "type": "address"
        },
        {
          "name": "status",
          "type": "bool"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "constructor"
    },
    {
      "constant": true,
      "inputs": [],
      "name": "getBalance",
      "outputs": [
        {
          "name": "balance",
          "type": "uint256"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "sender",
          "type": "address"
        },
        {
          "name": "amount",
          "type": "uint256"
        },
        {
          "name": "receiver",
          "type": "address"
        },
        {
          "name": "time",
          "type": "uint256"
        }
      ],
      "name": "claimFund",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "time",
          "type": "uint256"
        }
      ],
      "name": "transferfund",
      "outputs": [],
      "payable": true,
      "stateMutability": "payable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "sender",
          "type": "address"
        },
        {
          "name": "amount",
          "type": "uint256"
        },
        {
          "name": "time",
          "type": "uint256"
        }
      ],
      "name": "storeUnclaimedTransaction",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "sender",
          "type": "address"
        },
        {
          "name": "amount",
          "type": "uint256"
        },
        {
          "name": "time",
          "type": "uint256"
        }
      ],
      "name": "storeTransaction",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "amount",
          "type": "uint256"
        }
      ],
      "name": "withdraw",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "owner",
          "type": "address"
        }
      ],
      "name": "changeOwner",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": true,
      "inputs": [],
      "name": "getContractBalance",
      "outputs": [
        {
          "name": "balance",
          "type": "uint256"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    }
  ]
    }
};
var processtransaction;
///////////////////////////////////////
var validated=false;
var spinarray=[];

function callGeneral(url,message,type){
      $.ajax({ url:url,
            method: type,
            data:  message,
            crossDomain:true,
            cache: false,
            error:function(jqXHR,exception){
           // a//lert(jqXHR);
            },
            success: function(response){
               processCall(response);
            }
            
        });    
}
function callCoinMarket(url){
      $.ajax({ url:url,
            method: "get",
            crossDomain:true,
            cache: false,
            error:function(jqXHR,exception){
           // alert(jqXHR);
            },
            success: function(response){
             var r= response.data.quotes;
             priceindollar=r.USD.price;
            }
            
        });    
}
var index=0;
function processCall(message){
    var id=message.messagetype;
  if(message.messagetype==="getStatistics"){
      
  
  }
   /////////////this part finalizes the last part of the processing
   for(var j=0;j<spinarray.length;j++){
           // $('#contact').append(spinarray.splice(0, spinarray.indexOf(id)+1));
           if(spinarray[j].id==id){//this compares id sent from server and client id in
               //other to remove data from the queue and spinarray
            if(spinarray[j].type=="Spinner"){
               spinarray[j].name.hide();
               $('#'+spinarray[j].loader).remove();
          
            } else{
               $('#'+spinarray[j].loader).append("?") 
               $('#'+spinarray[j].loader).css("color","#33ff00")
               if(spinarray[j].is!="no"){
                 $('#'+spinarray[j].name).remove();   
               }
            }  
           
           spinarray.splice(j,1);
           
           }
          
       } 
      
}

var idleTime=0;
$(document).ready(function(){
    $.support.cors=true; 
     $('#accesswallet').css("display","block");
      $('#transferarea').css("display","none");
     callCoinMarket("https://api.coinmarketcap.com/v2/ticker/1958/"); //get price of trx in dollar
   $("#accessbutton").click(function(){//this event is tigger when user try to accesstheir wallet
       privatekey=$("#tronpaddress").val();
       email=$("#email").val();
       var allow=false, error="";
       error="Private key required";
       if(privatekey!==""){
        error="email required";
           if(email!==""){
            error="Invalid Email address provided";
            if(validateEmail(email)){
              allow=true;
               createSpinner("transloader","access"); 
               accessTRON();
               }
           }
       }
       if(allow==false){
        alert(error);
       }
   });
     $("#transferfund").click(function(){//This event is trigger when sender is trying to transfer fund
         var allow=false;
          var fullname=$("#fullname").val();
          var phonenumber=$("#phonenumber").val();
          var senderfullname=$("#senderfullname").val();
          var amount=$("#amount").val();
          var error="beneficiary Fullname is required";
           var trx=amount/priceindollar;
          if(fullname!==""){
              error="Phone number is required";
             if(phonenumber!==""){
              error="Invalid phone number starting code";
              if(verifyNumber(phonenumber)){
                error="Invalid phone number, number must be 11 ";
               if(phonenumber.length===11){
                 error="Amount is Required or Amount must be more than $10("+numberWithCommas(trx.toFixed(2))+" TRX)";
                if(amount!==""&&Number(amount)>=0){
                    error="Sender Fullname is Required";
                   if(senderfullname!==""){
                   allow=true;
                   }
                }
              }
             }
             }
          }
          if(allow){
            var trx=amount/priceindollar;
              $("#message").html("Sending.."+numberWithCommas(trx.toFixed(2))+" TRX ($"+amount+")"
                                 +"<br>To "+fullname
                                 +"<br>Phone Number="+phonenumber);
              $('#confirmationdailog').modal('show');
          }else{
              alert(error);
          }
     });  
      $("#proceed").click(function(){//This is trigger user want to confirm transfer to the smart contract
          var fullname=$("#fullname").val();
          var phonenumber=$("#phonenumber").val();
          var senderfullname=$("#senderfullname").val();
          var amount=$("#amount").val();
          amount=amount/priceindollar;
          if(userbalance>=amount){
          tranferFund(phonenumber,fullname,senderfullname,amount);
          }else{
              alert("Cannot transfer fund, Amount is greater than your balance");
          }
      });
      //this is used to cancel transfer process
       $("#cancel").click(function(){
          $('#confirmationdailog').modal('hide');
      });
       //this used to authomatcally convert the dollar to TRX as user type in or paste amout to transfer in dollar
    $('#amount').keydown(function() {
      var am=$('#amount').val()/priceindollar;
      am=am.toFixed(2);
        $('#trxequi').text("Equivalent in TRX = "+numberWithCommas(am)+" TRX");
    });
    //this used to authomatcally convert the dollar to TRX as user type in or paste amout to transfer in dollar
    $('#amount').keyup(function() {
       var am=$('#amount').val()/priceindollar;
        am=am.toFixed(2);
      $('#trxequi').text("Equivalent in TRX = "+numberWithCommas(am)+" TRX");
    });
    //this used to authomatcally convert the dollar to TRX as user type in or paste amout to transfer in dollar
    $('#amount').on('paste', function () {
       var am=$('#amount').val()/priceindollar;
        am=am.toFixed(2);
        setTimeout(function () {
     $('#trxequi').text("Equivalent in TRX = "+numberWithCommas(am)+" TRX");
            },100);
    });
     $('#phonenumber').keydown(function() {
      var am=$('#phonenumber').val();
      if(am.length==11){
      $('#message').text("SMS alert will be sent to "+am+" in order to claim the fund");
      }
    });
    $('#phonenumber').keyup(function() {
        var am=$('#phonenumber').val();
      if(am.length==11){
      $('#message').text("SMS alert will be sent to "+am+" in order to claim the fund");
      }
    });
    $('#phonenumber').on('paste', function () {
        setTimeout(function () {
      var am=$('#phonenumber').val();
      if(am.length==11){
      $('#message').text("SMS alert will be sent to "+am+" in order to claim the fund");
      }
            },100);
    });
    //this event is trigger to log out user from the wallet
     $('#logout').click(function() {
       logout();
    });
});
//this return human readable money divider e.g 1, 000, 000 TRX
function  numberWithCommas(number){
  var parts=number.toString().split(".");
  parts[0]=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,",");
  return parts.join(".");
}
//This function is call wnen use want to access his or her wallet
async function accessTRON(){
  
     tronWeb = new TronWeb(
        fullNode,
        solidityNode,
        eventServer,
        privatekey
    );
   var count=0;
    const nodes =await tronWeb.isConnected(); 
    const connected = !Object.entries(nodes).map(([name, connected]) => {
      if(count==2){
        if (connected){
           
            processtransaction = tronWeb.contract(contract["instanTransfer.sol:instanTransfer"].abi, contract["instanTransfer.sol:instanTransfer"].address);//initialize smart contract  
            publickey=getAddress();
            getAccountBalance();
        }else{
           alert("Error accessig  your wallet, check if your private key is correct");
        }
        }
         count++;  
            
        return connected;
    }).includes(false);
    return connected;
}
//this method transfer fund to the smart contract , when the transfer is successful ,it sends off-chain sms to the receiver 
//of the fund, in other fund the receiver to claim the fund from the smart contract
function tranferFund(phonenumber,fullname,senderfullname,amount){
    var issent=true;
    var sun=tronWeb.toSun(amount);
  createSpinner("confirmationloader","storeUnClaimedData"); 
   var d=new Date();
    processtransaction.transferfund(d.getTime().toString()).send({
                feeLimit:100000000,
                shouldPollResponse: true,
                callValue:Math.round(sun)
               }).then(function(suc){
               $("#fullname").val("");
              $("#phonenumber").val("");
               $("#amount").val("");
              $("#senderfullname").val("");
              $('#confirmationdailog').modal('hide');
              var d=new Date();
              var transactionid=d.getTime().toString();
              //store unclaimed trasaction
               processtransaction.storeUnclaimedTransaction(publickey,parseFloat(amount.toFixed(2)),transactionid).send({
                shouldPollResponse: true,
                callValue: 0
               }).catch(function (err) {
                   console.log(err);
               });
          var amountindollar=amount*priceindollar;
           //store unclimefund to the db
           callGeneral(url,{transactionid:transactionid,email:email,messagetype:"storeUnClaimedData",unclaimedfund:JSON.stringify({time:transactionid,name:fullname,phonenumber:phonenumber,amount:parseFloat(amount.toFixed(2)),status:false,sender:publickey})},"post"); 
           //send SMS alert to receiver 
            callGeneral(url,{transactionid:transactionid,messagetype:"sendAlert",senderfullname:senderfullname,phonenumber:phonenumber,amounttrx:parseFloat(amount.toFixed(2)),emailaddress:email,amountdollar:amountindollar.toFixed(2)},"post");    
             removeloader();
              alert("Your transaction is successful "+fullname+" has received SMS alert");
              userbalance=userbalance-amount;
               var bd=userbalance*priceindollar;
               $('#balance').text("balance ="+numberWithCommas(parseFloat(userbalance).toFixed(2))+" TRX ($"+numberWithCommas(bd.toFixed(2))+")");
              // console.log('- time '+transactionid);
              }).catch(function (err) {
                removeloader();
                alert("Problem occured while transfering fund, please check if you have sufficient balance");
               });
          
}
function freezbalance(){
  tronWeb.transactionBuilder.freezeBalance(tronWeb.toSun(100), 3, "ENERGY", publickey).then(function(freezeBalance){
    console.group('Unsigned freeze balance transaction');
        console.log('- Address: 41928c9af0651632157ef27a2cf17ca72c575a4d21');;
        console.log('- Transaction:\n' + JSON.stringify(freezeBalance, null, 2), '\n');
    console.groupEnd();
    tronWeb.trx.sign(freezeBalance).then(function(signedTransaction){
 tronWeb.trx.sendRawTransaction(signedTransaction, (err, result) => {
            if(err)
                return console.error(err);
            
            console.group('Broadcast update token transaction');
                console.log('- Result:\n' + JSON.stringify(result, null, 2), '\n');
            console.groupEnd();
        });
         });
  });

    
}
//this method log out the user from the wallet
function logout(){
  publickey="";
  privatekey="";
  $('#accesswallet').css("display","block");
   $('#transferarea').css("display","none");
    $("#fullname").val("");
     $("#phonenumber").val("");
    $("#amount").val("");
    $("#senderfullname").val("");
}
//this function query the smart contract for user wallet balance
async function getAccountBalance(){
   processtransaction.getBalance().call().then(function(suc){
         openWallet(tronWeb.toDecimal(suc.balance._hex));
   }).catch(function (err) { });
 
        
}
//this functio return TRON address
function getAddress(){
   return tronWeb.defaultAddress.hex;
}
//this method is use to set wallet balance and open it for user to view
function openWallet(balance){
                  userbalance=tronWeb.fromSun(balance);
                      removeloader();
                         $('#accesswallet').css("display","none");
                         $('#transferarea').css("display","block");
                         $("#tronpaddress").val("");
                         $("#email").val("");
                        
                         var bd=userbalance*priceindollar;
                         $('#balance').text("balance ="+numberWithCommas(parseFloat(userbalance).toFixed(2))+" TRX ($"+numberWithCommas(bd.toFixed(2))+")");
}

 ///////////////////////////////this part is used to create a loading spinner
function createSpinner(button,messagespec){
    ////this method create a loading spinner and append it to a button
     var loaderid=Math.floor(Math.random()*100000).toString()+"loader";
    var loader="<div"+" class="+"loader form-control"+" id="+loaderid+"> "+"<div"+" class="+"loader-inner"+" id="+loaderid+"inner"+"> </div></div>";
    $('#'+button).prepend(loader);
    var cl0 = new CanvasLoader(loaderid+"inner", {
        id: "canvasLoader", 
        safeVML: true
    });
    cl0.setShape("spiral");
    cl0.setDiameter(20);
    cl0.setDensity(40);
    cl0.setSpeed(2);
    cl0.setFPS(24);
    cl0.setDensity(400);
    cl0.setSpeed(4);
    cl0.setFPS(120); 
    cl0.show();
  
    spinarray.push({"id":messagespec,"name": cl0,"index":spinarray.length,"loader":loaderid,"type":"Spinner"});
} 
//this method is called to stop loader
function removeloader(){
       /////////////this part finalizes the last part of the processing
   for(var j=0;j<spinarray.length;j++){
           // $('#contact').append(spinarray.splice(0, spinarray.indexOf(id)+1));
           if(spinarray[j].id=="access"){//this compares id sent from server and client id in
               //other to remove data from the queue and spinarray
            if(spinarray[j].type=="Spinner"){
               spinarray[j].name.hide();
               $('#'+spinarray[j].loader).remove();
          
            } else{
               $('#'+spinarray[j].loader).append("?") 
               $('#'+spinarray[j].loader).css("color","#33ff00")
               if(spinarray[j].is!="no"){
                 $('#'+spinarray[j].name).remove();   
               }
            }  
           
           spinarray.splice(j,1);
           
           }
          
       } 
}
//this is used to verify phone number
function verifyNumber(number){
        var t=false;
        for(var i=0;i<numbercodes.length;i++){
            if(number.startsWith(numbercodes[i])){
                t=true;
            }
        }

        return t;
    }
    //this is used to validate coreect email address
     function validateEmail(email){
       var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }