var Migrations = artifacts.require("./Migrations.sol");
var processTransfer = artifacts.require("./instanTransfer.sol");
module.exports = function(deployer) {
  deployer.deploy(Migrations);
  deployer.deploy(processTransfer);
};