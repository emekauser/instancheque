/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dapp;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import java.util.Iterator;
import org.bson.Document;

/**
 *
 * @author this database is used to store confidential information of beneficiary e.g phone number, account number, fullname e.t.c
 */
public class DBUtility {
    MongoClient mongo;
    MongoDatabase db;
    public DBUtility(){
       
     //  mongo=new MongoClient();
        
        //MongoCredential credentail=MongoCredential.createCredential("...............", "...........", "....................".toCharArray());
    }
    public boolean addGeneral(String collname,Document query){
         mongo=new  MongoClient("localhost",27017);
        db=mongo.getDatabase("..............");
        boolean res=false;
        MongoCollection<Document> col=db.getCollection(collname);
        col.insertOne(query);
        res=true;
         mongo.close();
        return res;
    }
    public boolean deleteGeneral(String collname,Document query){
         mongo=new  MongoClient("localhost",27017);
        db=mongo.getDatabase("..........");
          MongoCollection<Document> col=db.getCollection(collname);
          DeleteResult ur=col.deleteOne(query);
          mongo.close();
          if(ur.getDeletedCount()!=0){
              return true;
          }else{
              return false;
          }
          
    }
   // Iterator it=docs.iterator();
       //  while(it.hasNext()){
           //  Document d=(Document)it.next();
         //}
    public Document get(String collname,Document doc){
         mongo=new  MongoClient("localhost",27017);
        db=mongo.getDatabase("...........");
         MongoCollection<Document> col=db.getCollection(collname);
         FindIterable<Document> docs=col.find(doc);
          Iterator it=docs.iterator();
          Document d=null;
            while(it.hasNext()){
             d=(Document)it.next();
             }
             mongo.close();
         return d;
    }
    public FindIterable<Document> getAll(String collname,Document doc){
         mongo=new  MongoClient("localhost",27017);
        db=mongo.getDatabase(".................");
         MongoCollection<Document> col=db.getCollection(collname);
         FindIterable<Document> docs=col.find(doc);
          //mongo.close();
         return docs;
    }
    public FindIterable<Document> getAll(String collname){
         mongo=new  MongoClient("localhost",27017);
        db=mongo.getDatabase("...........");
         MongoCollection<Document> col=db.getCollection(collname);
         FindIterable<Document> docs=col.find();
         // mongo.close();
         return docs;
    }
    public FindIterable<Document> getALLandSort(String collname){
         mongo=new  MongoClient("localhost",27017);
        db=mongo.getDatabase("......");
        Document doc=new Document();
        doc.append("index", -1);
         MongoCollection<Document> col=db.getCollection(collname);
         
         FindIterable<Document> docs=col.find().sort(doc);
          
         return docs;
    }
    public boolean updateGeneral(String collname,Document data,Document query){
         mongo=new  MongoClient("localhost",27017);
        db=mongo.getDatabase(".........");
          MongoCollection<Document> col=db.getCollection(collname);
          UpdateResult ur=col.updateOne(query, data);
           mongo.close();
           if(ur.getModifiedCount()!=0){
              return true;
          }else{
              return false;
          }
    }
    public void closeDBConnection(){
        mongo.close();
    }
}
