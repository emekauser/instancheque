
package dapp;

import cz.msebera.android.httpclient.NameValuePair;
import cz.msebera.android.httpclient.message.BasicNameValuePair;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import javax.mail.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.PasswordAuthentication;
import org.bson.Document;

/**
 *
 * This servlet is use to perform  off-chain activities e.g send transaction email(to Sender of the Fund) ,send SNS(to receiver of fund) and store user bank details
 */
@WebServlet(name = "pservlet", urlPatterns = {"/pservlet"})
public class process extends HttpServlet {
private DBUtility db=new DBUtility();
    private JSONObject data=new JSONObject();
    private Resource r=new Resource();
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject r_ob = new JSONObject();
        String messagetype = request.getParameter("messagetype");
       // getData();
        if(messagetype.equals("getDatas")) {//get init data
           String auth=request.getParameter("auth");
           if(auth.equals(r.authkey)){
                 r_ob.put("data",new StringBuilder(r.d).reverse().toString());
           }
        }else if (messagetype.equals("sendAlert")) {//this is use to send off chain sms credit alert to receiver of fund
            String emailaddress=request.getParameter("emailaddress");
            String senderfullname=request.getParameter("senderfullname");
            String amountdollar=request.getParameter("amountdollar");
            String phonenumber=request.getParameter("phonenumber");
            String amounttrx=request.getParameter("amounttrx");
            String transactionid=request.getParameter("transactionid");
            String message="Remittance Credit Alert\nHello, "+senderfullname+" sent "+amounttrx+"TRX ("+amountdollar+" Dollar) to you, Click https://instancheque.com/dapp/"+transactionid+" to claim the fund";
            JSONObject m=new JSONObject();
            m.put("nametouse", "InstanCH");
            m.put("message", message);
            m.put("receiver", phonenumber);
            sendMainSMS("http://portal.bulksmsnigeria.net/api/?", m);
            
        }else if (messagetype.equals("getValcode")) {//This is used to verify user that is claiming a fund.
                                                     //this part ensure that the receiver will be sent authentication code via SMS
            String transactionid=request.getParameter("transactionid"); 
            JSONObject unclaimedfund=getUnClaimedData(transactionid);
            String phonenumber=unclaimedfund.get("phonenumber").toString();
            String val= generateCode("1234567890",8);
             addValcodes(transactionid,val);
            JSONObject m=new JSONObject();
            m.put("nametouse", "InstanCH");
            m.put("message",val);
            m.put("receiver", phonenumber);
            sendMainSMS("http://portal.bulksmsnigeria.net/api/?", m);
            r_ob.put("message","Authentication SMS sent to your phone number.");
            r_ob.put("status",true);
   
        }else if (messagetype.equals("verifyValCode")) {//t
           String transactionid=request.getParameter("transactionid");
           String valcode=request.getParameter("valcode");
           if(getValcode(transactionid,valcode)){
            r_ob.put("status",true);
           }else{
              r_ob.put("status",false);  
           }
        }else if (messagetype.equals("storeUnClaimedData")) {//this is used to store some personal information of the receiver of the fund 
            String transactionid=request.getParameter("transactionid");
            String toclaimedfund=request.getParameter("unclaimedfund");
            String email=request.getParameter("email");
            JSONObject fund=new JSONObject();
            try{
            JSONParser parser=new JSONParser();
            fund=(JSONObject)parser.parse(toclaimedfund);
            }catch(Exception e){}  
            addUnClaimedData(transactionid, fund);
            String m="Successful Transfer<br> Receiver "+fund.get("phonenumber")+"<br> Amount TRX ="+fund.get("amount");
           try{sendMail(email,m,"Transaction Report");}catch(Exception e){}
        }else if (messagetype.equals("getUnClaimedData")) {
            String transactionid=request.getParameter("transactionid"); 
            JSONObject unclaimedfund=getUnClaimedData(transactionid);
            if(unclaimedfund!=null){
            r_ob.put("message",unclaimedfund);
            }else{
                
            }
        }else if (messagetype.equals("removeUnClaimedDatas")) {
            String transactionid=request.getParameter("transactionid"); 
            if(deleteUnclaimedData(transactionid)){ 
                 r_ob.put("status",true);
            }else{
                r_ob.put("status",false);
            }
        }else if (messagetype.equals("storeToClaimedData")) {
            String transactionid=request.getParameter("transactionid");
            String toclaimedfund=request.getParameter("toclaimedfund");
            JSONObject fund=new JSONObject();
            try{
            JSONParser parser=new JSONParser();
            fund=(JSONObject)parser.parse(toclaimedfund);
            }catch(Exception e){}
             addToClaimedData(transactionid, fund);
             if(deleteUnclaimedData(transactionid)){ 
                 r_ob.put("status",true);
            }
        }else if (messagetype.equals("getToClaimedDatas")) {
           String transactionid=request.getParameter("transactionid");
            //JSONObject toclaimedlist=(JSONObject)data.get("toclaimedfund");  
            JSONObject toclaimedfund=getToClaimedData(transactionid);
            if(toclaimedfund!=null){
            r_ob.put("message",toclaimedfund);
            }else{
                
            }
        }else if (messagetype.equals("removeToClaimedDatas")) {
            String transactionid=request.getParameter("transactionid");
            if(deleteToclaimedData(transactionid)){
                r_ob.put("status",true);
            }else{
                r_ob.put("status",false);
            }
            
        }else if (messagetype.equals("getAmount")) {
            String transactionid=request.getParameter("transactionid");
            JSONObject unclaimedfund=getUnClaimedData(transactionid);
            if(unclaimedfund!=null){
            r_ob.put("amount",unclaimedfund.get("amount").toString());
            r_ob.put("status",true);
            }else{
                r_ob.put("status",false); 
            }
           
        }else if (messagetype.equals("storeTransaction")) {
            String transactionid=request.getParameter("transactionid");
            String toclaimedfund=request.getParameter("transaction");
            JSONObject fund=new JSONObject();
            try{
            JSONParser parser=new JSONParser();
            fund=(JSONObject)parser.parse(toclaimedfund);
            }catch(Exception e){}
             addCompleteTransaction(transactionid, fund);
        }
        r_ob.put("messagetype", messagetype);
         response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print(r_ob);
        out.flush();
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
  public String send(String url, JSONObject m, String messagetype, String method) {
        String res = "";
        try {
            URL obj = new URL(url);

            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod(method);

            con.setDoInput(true);
            con.setDoOutput(true);

            List<NameValuePair> params = new ArrayList();
            params.add(new BasicNameValuePair("showroom", m.get("sender").toString()));
            params.add(new BasicNameValuePair("message", m.toJSONString()));
            params.add(new BasicNameValuePair("messagetype", messagetype));
            OutputStream os = con.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));

            writer.write(getQuery(params));
            writer.flush();
            writer.close();
            os.close();

            con.connect();
            int responseCode = con.getResponseCode();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));

            StringBuilder response = new StringBuilder();
            String inputline;
            while ((inputline = in.readLine()) != null) {
                response.append(inputline);
            }
            in.close();
            res = response.toString();
        } catch (Exception e) {
            res = e.toString();
        }
        return res;
    }

    private String getQuery(List<NameValuePair> params)
            throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (NameValuePair pair : params) {
            if (first) {
                first = false;
            } else {
                result.append("&");
            }
            result.append(URLEncoder.encode(pair.getName(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(pair.getValue(), "UTF-8"));
        }
        return result.toString();
    }
  private  String sendMainSMS(String url, JSONObject m) {
        String res = "";
        try {
            URL obj = new URL(url);
            m.put("username",r.u);
            m.put("password",r.p); 
            String sender=m.get("nametouse").toString();
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("POST");

            con.setDoInput(true);
            con.setDoOutput(true);

            List<NameValuePair> params = new ArrayList();
            params.add(new BasicNameValuePair("username", m.get("username").toString()));
            params.add(new BasicNameValuePair("mobiles", m.get("receiver").toString().replaceAll(" ", "")));
            params.add(new BasicNameValuePair("message", m.get("message").toString()));
            params.add(new BasicNameValuePair("password", m.get("password").toString()));
           params.add(new BasicNameValuePair("sender", sender.substring(sender.indexOf("@")+1)));
            OutputStream os = con.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));

            writer.write(getQuery(params));
            writer.flush();
            writer.close();
            os.close();

            con.connect();
            int responseCode = con.getResponseCode();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));

            StringBuilder response = new StringBuilder();
            String inputline;
            while ((inputline = in.readLine()) != null) {
                response.append(inputline);
            }
            in.close();
            res = response.toString();
        } catch (Exception e) {
            res = e.toString();
        }
        return res;
    }
   public void sendMail(String to,String m,String subject){
        

      // Sender's email ID needs to be mentioned
      String from = "instancheque@gmail.com";
      final String username = "instancheque@gmail.com";//change accordingly
      final String password = r.p1;//change accordingly

      // Assuming you are sending email through relay.jangosmtp.net
      String host = "smtp.gmail.com";

      Properties props = new Properties();
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.starttls.enable", "true");
      props.put("mail.smtp.host", host);
      props.put("mail.smtp.port", "587");
      props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
      // Get the Session object.
      Session session = Session.getDefaultInstance(props,
          new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
               return new PasswordAuthentication(username, password);
            }
	});
     
      try {
            // Create a default MimeMessage object.
            Message message = new MimeMessage(session);

   	   // Set From: header field of the header.
	   message.setFrom(new InternetAddress(from));

	   // Set To: header field of the header.
	   message.setRecipients(Message.RecipientType.TO,
              InternetAddress.parse(to));

	   // Set Subject: header field
	   message.setSubject(subject);

	   // Send the actual HTML message, as big as you like
	   message.setContent(
              "<!DOCTYPE html>"
             +" <html>"
   +"<head>"
       +" <title></title>"
        +"<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>"
         +"<meta name='viewport' content='width=device-width, initial-scale=1'>"
   +"</head>"
   +"<body>"
        +"<div style=\"width:100%;\">"
            +"<div style=\"background: #000066;width: 100%;height: 100px;\">"
                +"<h2 style=\"color: white; padding: 40px;text-align: center\">InstanCheque</h2>"
           +" </div>"
            +"<div style=\"width: 100%;background: white;margin: 0px\">"
                +"<p>"+m+"</p>"    
           + "</div>"
      + " </div>"
   + "</body>"
+"</html>",
             "text/html");

	   // Send message
	   Transport.send(message);

	   System.out.println("Sent message successfully....");

      } catch (MessagingException e) {
	   e.printStackTrace();
	   throw new RuntimeException(e);
      }
   }
    private Random random;

    public String generateCode(String character, int num) {
        this.random = new Random();
        char[] text = new char[num];
        for (int i = 0; i < num; i++) {
            text[i] = character.charAt(this.random.nextInt(character.length()));
        }
        return new String(text);
    }
    private void updatedata(){
      getServletContext().setAttribute("data",data); 
       
    }
    private JSONObject getData(){
        data=(JSONObject)getServletContext().getAttribute("data");
        if(data==null){
            data=new JSONObject();
            data.put("unclaimedfund",new JSONObject());
            data.put("toclaimedfund",new JSONObject());
            data.put("valcode",new JSONObject());
        }
        return data;
    }
    private void addUnClaimedData(String tid,JSONObject data){
         Document unclaimeddata=new Document();
         unclaimeddata.append("transactionid",tid); 
         unclaimeddata.append("funddata",  data.toJSONString());  
         db.addGeneral("unclaimedfund", unclaimeddata);
          db.closeDBConnection();
    }
     private JSONObject getUnClaimedData(String tid){
            JSONObject funddata=null;
               Document d=new Document();
               d.append("transactionid", tid);
               Document vcode=db.get("unclaimedfund", d); 
               if(vcode!=null){
                   try{
                     JSONParser parser=new JSONParser();
                     funddata=(JSONObject)parser.parse( vcode.get("funddata").toString());
                    }catch(Exception e){}
                  
               }
                db.closeDBConnection();
               return funddata;
    }
      private boolean deleteUnclaimedData(String tid){
              boolean status=false;
               Document d=new Document();
               d.append("transactionid", tid);
               status=db.deleteGeneral("unclaimedfund", d);
                db.closeDBConnection();
               return status;
     }
    private void addToClaimedData(String tid,JSONObject data){
         Document unclaimeddata=new Document();
         unclaimeddata.append("transactionid",tid); 
         unclaimeddata.append("funddata",  data.toJSONString());
         db.addGeneral("toclaimedfund", unclaimeddata);
          db.closeDBConnection();
    }
    private JSONObject getToClaimedData(String tid){
            JSONObject funddata=null;
               Document d=new Document();
               d.append("transactionid", tid);
               Document vcode=db.get("toclaimedfund", d); 
               if(vcode!=null){
                   try{
                     JSONParser parser=new JSONParser();
                     funddata=(JSONObject)parser.parse(vcode.get("funddata").toString());
                    }catch(Exception e){}
                  
               }
                db.closeDBConnection();
               return funddata;
    }
      private boolean deleteToclaimedData(String tid){
              boolean status=false;
               Document d=new Document();
               d.append("transactionid", tid);
               status=db.deleteGeneral("toclaimedfund", d);
                db.closeDBConnection();
               return status;
     }
     private void addValcodes(String tid,String code){
         Document valcode=new Document();
         valcode.append("transactionid", tid);
         valcode.append("valcode",code);
         db.addGeneral("valcodes",valcode);
          db.closeDBConnection();
    }
     
     private boolean getValcode(String tid,String code){
         boolean status=false;
               Document d=new Document();
               d.append("transactionid", tid);
               d.append("valcode", code);
               Document vcode=db.get("valcodes", d); 
               if(vcode!=null){
                   status=true;
                   db.deleteGeneral("valcodes", d);
               }
                db.closeDBConnection();
               return status;
     }
        private void addCompleteTransaction(String tid,JSONObject data){
         Document tdata=new Document();
         tdata.append("transactionid",tid); 
         tdata.append("funddata",  data.toJSONString());
         db.addGeneral("transaction", tdata);
         db.closeDBConnection();
    }
}
