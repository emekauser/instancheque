package dapp;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//this class help to beautify URL and perform port forwarding and redirection
@WebFilter(filterName="rewrite", urlPatterns={"/*"}, dispatcherTypes={javax.servlet.DispatcherType.REQUEST})
public class rewrite
  implements Filter
{
  private PreparedStatement pst;
  private PreparedStatement pst1;
  private Statement st;
  private ResultSet rs;
  private Connection connect;
  private DriverManager dm;
  private static final boolean debug = true;
  private FilterConfig filterConfig = null;
  
  private void doBeforeProcessing(ServletRequest request, ServletResponse response)
    throws IOException, ServletException
  {
    log("rewrite:DoBeforeProcessing");
  }
  
  private void doAfterProcessing(ServletRequest request, ServletResponse response)
    throws IOException, ServletException
  {
    log("rewrite:DoAfterProcessing");
  }
  
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    boolean is = false;
    int ifredirected = 0;
    
    HttpServletRequest req = (HttpServletRequest)request;
    HttpServletResponse res = (HttpServletResponse)response;
    doBeforeProcessing(request, response);
    String url = req.getRequestURI();
    ServletContext context = req.getServletContext();
    String param = url.substring(url.lastIndexOf("/") + 1);
    if(!url.contains("dapp")){
        res.sendRedirect(res.encodeRedirectURL(req.getContextPath() + "/dapp/index.html" ));
    }else{
    if ((url.endsWith(".jsp")) || (url.endsWith(".html")) || (url.endsWith(".js")) || (url.endsWith(".css")) || (url.endsWith(".xml")) || (url.endsWith(".jpg")) || (url.endsWith(".svg")) || (url.endsWith(".png")) || (url.endsWith(".ico")) || (url.endsWith(".mp3")) || (url.endsWith(".wav")) || (url.endsWith(".eot")) || (url.endsWith(".ttf")) || (url.endsWith(".woff")) || (url.endsWith("process")) )
    {
      log("request comming from" + url);
      if ((url.substring(url.lastIndexOf("/") + 1).equals("index.jsp")) || (url.substring(url.lastIndexOf("/") + 1).equals("login.jsp")))
      {
     
      }
     
    }else {
      log("request comming from" + url);
      if (param.isEmpty()){
        context.getRequestDispatcher("/index.html").forward(request, response);
      } else{
       // res.sendRedirect(res.encodeRedirectURL(req.getContextPath() + "/claimfund.jsp?tid=" + id ));
         request.setAttribute("tid", param);
         context.getRequestDispatcher("/claimfund.jsp").forward(request, response);
         is = true;
      }
    }
    }
    Throwable problem = null;
    try
    {
      if (!is)
      {
        if (ifredirected != 1) {
          chain.doFilter(request, response);
        }
      }
    }
    catch (Throwable t)
    {
      problem = t;
      t.printStackTrace();
    }
    doAfterProcessing(request, response);
    if (problem != null)
    {
      if ((problem instanceof ServletException)) {
        throw ((ServletException)problem);
      }
      if ((problem instanceof IOException)) {
        throw ((IOException)problem);
      }
      sendProcessingError(problem, response);
    }
  }
  
  
  public FilterConfig getFilterConfig()
  {
    return this.filterConfig;
  }
  
  public void setFilterConfig(FilterConfig filterConfig)
  {
    this.filterConfig = filterConfig;
  }
  
  public void destroy() {}
  
  public void init(FilterConfig filterConfig)
  {
    this.filterConfig = filterConfig;
    if (filterConfig != null) {
      log("rewrite:Initializing filter");
    }
  }
  
  public String toString()
  {
    if (this.filterConfig == null) {
      return "rewrite()";
    }
    StringBuffer sb = new StringBuffer("rewrite(");
    sb.append(this.filterConfig);
    sb.append(")");
    return sb.toString();
  }
  
  private void sendProcessingError(Throwable t, ServletResponse response)
  {
    String stackTrace = getStackTrace(t);
    if ((stackTrace != null) && (!stackTrace.equals(""))) {
      try
      {
        response.setContentType("text/html");
        PrintStream ps = new PrintStream(response.getOutputStream());
        PrintWriter pw = new PrintWriter(ps);
        pw.print("<html>\n<head>\n<title>Error</title>\n</head>\n<body>\n");
        
        pw.print("<h1>The resource did not process correctly</h1>\n<pre>\n");
        pw.print(stackTrace);
        pw.print("</pre></body>\n</html>");
        pw.close();
        ps.close();
        response.getOutputStream().close();
      }
      catch (Exception ex) {}
    } else {
      try
      {
        PrintStream ps = new PrintStream(response.getOutputStream());
        t.printStackTrace(ps);
        ps.close();
        response.getOutputStream().close();
      }
      catch (Exception ex) {}
    }
  }
  
  public static String getStackTrace(Throwable t)
  {
    String stackTrace = null;
    try
    {
      StringWriter sw = new StringWriter();
      PrintWriter pw = new PrintWriter(sw);
      t.printStackTrace(pw);
      pw.close();
      sw.close();
      stackTrace = sw.getBuffer().toString();
    }
    catch (Exception ex) {}
    return stackTrace;
  }
  
  public void log(String msg)
  {
    this.filterConfig.getServletContext().log(msg);
  }
  
 
}
