/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dapp;

/**
 *
 * @author user
 */
//information in this class is confidential it can amount to security risk
public class Resource {
    public final String d="............";
    public final String authkey="...........";
    public final String u="..............";
    public final String p=".......";
    public final String p1="..........";
    public Resource(){
        
    }
}
